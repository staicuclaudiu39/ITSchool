import logo from './logo.svg';
import './App.css';
import Card from './components/Card';

function App() {
  return (
    <div className='MainPage'>
       <p className='title'>Lista membrilor din EESTEC</p>
       <Card/>
    </div>
  );
}

export default App;
